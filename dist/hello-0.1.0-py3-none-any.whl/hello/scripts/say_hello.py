from colorama import Fore


def main():
    print(Fore.RED + "Hello!")


if __name__ == '__main__':
    main()
